"use client";

import { useState } from "react";
import { supabase } from "../lib/supabase";
import { useRouter } from "next/navigation";

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSignup = async () => {
    setError("");

    if (!fullName || !email || !password || !confirmPassword) {
      setError("Please fill in all fields.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    setLoading(true);

    const { data, error: signUpError } = await supabase.auth.signUp({ email, password });

    if (signUpError) {
      setLoading(false);
      setError(signUpError.message);
      return;
    }

    // Insert into doctors table
    if (data.user) {
      const { error: insertError } = await supabase.from("doctors").insert({
        user_id: data.user.id,
        full_name: fullName,
        email: email,
      });
      if (insertError) {
        setLoading(false);
        setError("Account created but profile setup failed. Please contact support.");
        return;
      }
    }

    setLoading(false);
    setSuccess(true);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#f8faff", display: "flex", fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .fade-up   { animation: fadeUp 0.6s ease both; }
        .fade-up-2 { animation: fadeUp 0.6s 0.1s ease both; }
        .fade-up-3 { animation: fadeUp 0.6s 0.2s ease both; }
        .fade-up-4 { animation: fadeUp 0.6s 0.3s ease both; }

        .input-field {
          width: 100%;
          padding: 13px 16px;
          border: 1.5px solid #e0eaff;
          border-radius: 12px;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.95rem;
          color: #0f172a;
          background: #fff;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
        }
        .input-field:focus {
          border-color: #1d4ed8;
          box-shadow: 0 0 0 4px rgba(29,78,216,0.08);
        }
        .input-field::placeholder { color: #94a3b8; }

        .btn-primary {
          width: 100%;
          padding: 14px;
          background: #1d4ed8;
          color: #fff;
          font-family: 'DM Sans', sans-serif;
          font-weight: 600;
          font-size: 0.95rem;
          border: none;
          border-radius: 12px;
          cursor: pointer;
          transition: background 0.2s, transform 0.15s, box-shadow 0.2s;
          box-shadow: 0 4px 18px rgba(29,78,216,0.25);
        }
        .btn-primary:hover:not(:disabled) {
          background: #1e40af;
          transform: translateY(-1px);
          box-shadow: 0 8px 24px rgba(29,78,216,0.32);
        }
        .btn-primary:disabled { opacity: 0.7; cursor: not-allowed; }

        .panel-left { display: none; }
        @media (min-width: 900px) {
          .panel-left { display: flex; }
        }
      `}</style>

      {/* Left decorative panel */}
      <div className="panel-left" style={{ width: "45%", background: "linear-gradient(145deg, #0f172a 0%, #1e3a8a 50%, #1d4ed8 100%)", flexDirection: "column", justifyContent: "center", alignItems: "center", padding: "60px", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -80, right: -80, width: 300, height: 300, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
        <div style={{ position: "absolute", bottom: -60, left: -60, width: 220, height: 220, borderRadius: "50%", background: "rgba(255,255,255,0.04)" }} />

        <div style={{ position: "relative", textAlign: "center" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 48 }}>
            <div style={{ width: 36, height: 36, background: "rgba(255,255,255,0.15)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="20" height="20" viewBox="0 0 18 18" fill="none">
                <path d="M9 2v14M2 9h14" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"/>
              </svg>
            </div>
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 700, fontSize: "1.3rem", color: "#fff" }}>MedHub</span>
          </div>

          <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "2.2rem", color: "#fff", lineHeight: 1.2, marginBottom: 20 }}>
            Join the future<br />of medical care
          </h2>
          <p style={{ color: "rgba(255,255,255,0.7)", fontSize: "0.95rem", lineHeight: 1.7, maxWidth: 300 }}>
            Create your secure MedHub account and take control of your professional documents and agency relationships.
          </p>

          <div style={{ marginTop: 56, background: "rgba(255,255,255,0.07)", borderRadius: 16, padding: "24px", border: "1px solid rgba(255,255,255,0.1)" }}>
            <p style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.75rem", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>What you get</p>
            {["Private document vault", "GMC profile management", "One-click agency sharing", "Compliance tracking"].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: i < 3 ? 10 : 0 }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#60a5fa", flexShrink: 0 }} />
                <span style={{ color: "rgba(255,255,255,0.8)", fontSize: "0.88rem" }}>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right form panel */}
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 24px" }}>
        <div style={{ width: "100%", maxWidth: 420 }}>

          {/* Mobile logo */}
          <div className="fade-up" style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 40 }}>
            <div style={{ width: 30, height: 30, background: "#1d4ed8", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
                <path d="M9 2v14M2 9h14" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"/>
              </svg>
            </div>
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "#1d4ed8" }}>MedHub</span>
          </div>

          {success ? (
            <div className="fade-up" style={{ textAlign: "center", padding: "40px 0" }}>
              <div style={{ width: 64, height: 64, background: "#eff6ff", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px" }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="#1d4ed8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "1.8rem", color: "#0f172a", marginBottom: 12 }}>Account created!</h2>
              <p style={{ color: "#64748b", fontSize: "0.92rem", lineHeight: 1.7, marginBottom: 32 }}>
                Please check your email to confirm your account, then sign in to access your MedHub dashboard.
              </p>
              <a href="/login" style={{ display: "inline-block", background: "#1d4ed8", color: "#fff", fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: "0.95rem", padding: "14px 32px", borderRadius: 12, textDecoration: "none" }}>
                Go to Sign In
              </a>
            </div>
          ) : (
            <>
              <div className="fade-up-2">
                <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "2rem", color: "#0f172a", marginBottom: 8, letterSpacing: "-0.02em" }}>Create account</h1>
                <p style={{ color: "#64748b", fontSize: "0.92rem", marginBottom: 36 }}>
                  Already have an account?{" "}
                  <a href="/login" style={{ color: "#1d4ed8", fontWeight: 600, textDecoration: "none" }}>Sign in</a>
                </p>
              </div>

              <div className="fade-up-3" style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                <div>
                  <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#374151", marginBottom: 8 }}>Full name</label>
                  <input className="input-field" type="text" placeholder="Dr. Jane Smith" value={fullName} onChange={e => setFullName(e.target.value)} />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#374151", marginBottom: 8 }}>Email address</label>
                  <input className="input-field" type="email" placeholder="doctor@example.com" value={email} onChange={e => setEmail(e.target.value)} />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#374151", marginBottom: 8 }}>Password</label>
                  <input className="input-field" type="password" placeholder="Min. 6 characters" value={password} onChange={e => setPassword(e.target.value)} />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#374151", marginBottom: 8 }}>Confirm password</label>
                  <input className="input-field" type="password" placeholder="••••••••" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} onKeyDown={e => e.key === "Enter" && handleSignup()} />
                </div>

                {error && (
                  <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 10, padding: "12px 16px", color: "#dc2626", fontSize: "0.88rem" }}>
                    {error}
                  </div>
                )}
              </div>

              <div className="fade-up-4" style={{ marginTop: 24 }}>
                <button className="btn-primary" onClick={handleSignup} disabled={loading}>
                  {loading ? "Creating account..." : "Create my MedHub account"}
                </button>
              </div>

              <p className="fade-up-4" style={{ marginTop: 24, fontSize: "0.78rem", color: "#94a3b8", textAlign: "center", lineHeight: 1.6 }}>
                By creating an account you agree to MedHub&apos;s Terms of Service and Privacy Policy.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
